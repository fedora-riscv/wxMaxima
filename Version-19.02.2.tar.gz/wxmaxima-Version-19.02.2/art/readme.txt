Toolbar icons (in toolbar/ subdirectory) and the config icons (in
config/ subdirectory) are from the Tango project
(http://tango.freedesktop.org). They originally were released under
the Creative Commons Attribution Share-Alike license
(https://creativecommons.org/licenses/by-sa/2.5/) but since then have
been released to the public domain.
They were renamed to match the names of the gtk system icons they
replace.


wxMaxima icons (wxmac.icns, maximaicon.ico, io.github.wxmaxima_developers.wxMaxima.png) were created
by Sven Hodapp and are licensed under GPL.
io.github.wxmaxima_developers.wxMaxima.svg was an attempt to make a scaleable vector image that
resembles these icons by Gunter Königsmann (http://www.physikbuch.de)
and is under GPL, too.
